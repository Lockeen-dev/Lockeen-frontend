insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'study-materials',
  'study-materials',
  false,
  10485760,
  array['application/pdf', 'image/png', 'image/jpeg', 'text/plain']
)
on conflict (id) do update
set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage'
      and tablename = 'objects'
      and policyname = 'study materials select own'
  ) then
    create policy "study materials select own" on storage.objects
    for select to authenticated
    using (
      bucket_id = 'study-materials'
      and (storage.foldername(name))[1] = auth.uid()::text
    );
  end if;
end $$;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage'
      and tablename = 'objects'
      and policyname = 'study materials insert own'
  ) then
    create policy "study materials insert own" on storage.objects
    for insert to authenticated
    with check (
      bucket_id = 'study-materials'
      and (storage.foldername(name))[1] = auth.uid()::text
    );
  end if;
end $$;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage'
      and tablename = 'objects'
      and policyname = 'study materials update own'
  ) then
    create policy "study materials update own" on storage.objects
    for update to authenticated
    using (
      bucket_id = 'study-materials'
      and (storage.foldername(name))[1] = auth.uid()::text
    )
    with check (
      bucket_id = 'study-materials'
      and (storage.foldername(name))[1] = auth.uid()::text
    );
  end if;
end $$;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage'
      and tablename = 'objects'
      and policyname = 'study materials delete own'
  ) then
    create policy "study materials delete own" on storage.objects
    for delete to authenticated
    using (
      bucket_id = 'study-materials'
      and (storage.foldername(name))[1] = auth.uid()::text
    );
  end if;
end $$;
